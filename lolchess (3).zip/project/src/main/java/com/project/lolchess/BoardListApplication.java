package com.project.lolchess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardListApplication {
    public static void main(String[] args) {
        SpringApplication.run(BoardListApplication.class, args);
    }
}
